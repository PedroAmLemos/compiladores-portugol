//
// Created by pedroamlemos on 20/10/22.
//

#ifndef LEXICO_C_SINTATICO_H
#define LEXICO_C_SINTATICO_H

#include "pilha.h"

int parser(int input_tolken, int stack_tolken, Stack *stack);

#endif //LEXICO_C_SINTATICO_H
